package sample;

public class DataClass {
}
